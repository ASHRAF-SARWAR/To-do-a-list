export default function Stats({ items }) {
  if (!items.length) {
    return (
      <footer className="stats">
        <em>Starting Packing up for Travel! 💼</em>
      </footer>
    );
  }
  const numItems = items.length;
  const packedItems = items.filter((item) => item.packed).length;
  const percent = Math.round((packedItems / numItems) * 100);
  return (
    <footer className="stats">
      <em>
        {percent === 100
          ? `You are Ready to Travel, you packed up! ✈️`
          : `You have ${numItems} items in your list and You already have packed
        ${packedItems} (${percent}%) `}
      </em>
    </footer>
  );
}
